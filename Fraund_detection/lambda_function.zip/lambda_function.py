import json
import logging
import base64 # Required to decode the Kafka message value

logger = logging.getLogger()
logger.setLevel(logging.INFO) # Set logging level to INFO or DEBUG for more details

def lambda_handler(event, context):
    """
    Lambda function that processes messages from a Kafka event source.
    For this initial step, it simply logs the received messages to CloudWatch.
    """
    logger.info(f"Received event: {json.dumps(event)}")

    if 'records' not in event:
        logger.warning("Event does not contain 'records' key. Skipping processing.")
        return {
            'statusCode': 200,
            'body': json.dumps('No Kafka records to process.')
        }

    processed_messages = 0
    for topic_partition, records in event['records'].items():
        for record in records:
            try:
                # Kafka message value is Base64 encoded.
                # The key is also Base64 encoded if present, but we only expect value here.
                decoded_value = base64.b64decode(record['value']).decode('utf-8')
                transaction_data = json.loads(decoded_value)
                
                logger.info(f"Processing transaction: [ID: {transaction_data.get('transaction_id', 'N/A')}, Amount: {transaction_data.get('amount', 'N/A')}, Is Fraud (GT): {transaction_data.get('is_fraud', 'N/A')}]")
                
                # Future steps will involve feature engineering and model inference here.
                # For now, this logging confirms successful reception and parsing.

                processed_messages += 1

            except Exception as e:
                logger.error(f"Error processing record: {record}. Error: {e}", exc_info=True) # exc_info=True adds stack trace
    
    logger.info(f"Successfully processed {processed_messages} messages.")

    return {
        'statusCode': 200,
        'body': json.dumps(f'Successfully processed {processed_messages} messages.')
    }